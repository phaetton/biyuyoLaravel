<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight flex items-center justify-between">
            <?php echo e(__('Listado de imagenes')); ?>

            <a href="<?php echo e(route('imagenes.create')); ?>" class="px-4 py-2 rounded-lg text-white bg-gray-800 hover:bg-gray-900 font-bold  shadow-lg shadow-gray-200 transition ease-in-out duration-200 translate-10">Crear</a>

        </h2>
     <?php $__env->endSlot(); ?>




    <div class="py-12">
        <div class=" container mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6  border-b border-gray-200">
                    <div class="grid grid-cols-4 -m-1 md:-m-2 gap-2">
                        <?php $__empty_1 = true; $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <a class="relative block border border-gray-100" href="/product/build-your-own-drone">


                            <img class="object-contain w-full h-56 lg:h-72" src="<?php if(isset($imagen->imagen)): ?> ../images/imagenes/<?php echo e($imagen->imagen); ?> <?php else: ?> ../images/user_placeholder.png <?php endif; ?>" alt="Build Your Own Drone" loading="lazy" />

                            <div class="p-6">


                                <h5 class="mt-4 text-lg font-bold">
                                    <?php echo e($imagen->negocio_id); ?> - <?php echo e($imagen->nombre); ?>

                                </h5>

                                <p class="mt-2 text-sm text-gray-700 overflow-y-hidden h-20 w-full ">
                                    <?php echo e($imagen->descripcion); ?>

                                </p>



                                <form action="<?php echo e(route('imagenes.destroy',$imagen)); ?>" class="" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <input type="submit" value="Eliminar" onclick="return confirm('¿Desea eliminar?')" class="block w-full p-4 mt42  text-white bg-gray-800 hover:bg-gray-900 font-bold  shadow-lg shadow-gray-200 transition ease-in-out duration-200 translate-10" />
                                </form>
                            </div>
                        </a>


                        <!-- <div class="flex flex-wrap w-1/3">
                                    <div class="w-full p-1 md:p-2">
                                        <img alt="gallery" class="block object-cover object-center w-full h-full rounded-lg" src="<?php if(isset($imagen->imagen)): ?> images/imagenes/<?php echo e($imagen->imagen); ?> <?php else: ?> images/user_placeholder.png <?php endif; ?>">
                                    </div>
                                   
                                </div> -->











                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        Upps! no hay ninguna publicacion disponible
                        <?php endif; ?>
                    </div>
                    <?php echo e($imagenes->links()); ?>

                </div>
            </div>
        </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\biyuyo\resources\views/imagenes/index.blade.php ENDPATH**/ ?>