<!DOCTYPE html>

<?php
include 'includes/header.php'; 
?>

    </div>
    <body>
        <div class="container-fluid overflow-hidden">
            <h3 class="text-center mt-3">NUESTRA MISION</h3>
            <div class="row m-5">
                <div class="card col-md-12 col-sm-12">
                    <div style="text-align: center;">
                        <p><i class="far fas fa-users"></i></p>
                        <p>
                            Elevar generaciones en los países en vías de desarrollo al dirigir individuos y familias de la pobreza a la autosuficiencia sostenible a través de la mentoría personalizada y capacitación vocacional.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </body>
    <?php
include 'includes/footer.php'; 
?>
    <!--Fin de footer -->
</body>

</html>
